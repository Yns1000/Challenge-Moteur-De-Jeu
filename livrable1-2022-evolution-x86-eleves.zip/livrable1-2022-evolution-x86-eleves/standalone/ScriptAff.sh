#!/bin/bash

xdg-open ../web/avalam-refresh.html 
for i in {3..1}; do echo $i; sleep 1; done;
